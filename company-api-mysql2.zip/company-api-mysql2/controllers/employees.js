
const pool = require('../db');

exports.getAll = async (req, res) => {
  try {
    const sql = `
      SELECT e.id_employees, e.employee_name, e.employee_email, e.hire_date,
             e.department_id, d.department_name, d.id_division, dv.division_name
      FROM employees e
      LEFT JOIN department d ON e.department_id = d.id_department
      LEFT JOIN division dv ON d.id_division = dv.id_division
      ORDER BY e.id_employees`;
    const [rows] = await pool.query(sql);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.getById = async (req, res) => {
  try {
    const sql = `
      SELECT e.id_employees, e.employee_name, e.employee_email, e.hire_date,
             e.department_id, d.department_name, d.id_division, dv.division_name
      FROM employees e
      LEFT JOIN department d ON e.department_id = d.id_department
      LEFT JOIN division dv ON d.id_division = dv.id_division
      WHERE e.id_employees = ?`;
    const [rows] = await pool.query(sql, [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Employee not found' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.create = async (req, res) => {
  const { employee_name, employee_email, department_id, hire_date } = req.body;
  if (!employee_name || !employee_email) return res.status(400).json({ message: 'employee_name and employee_email are required' });
  try {
    const [result] = await pool.query('INSERT INTO employees (employee_name, employee_email, department_id, hire_date) VALUES (?, ?, ?, ?)', [employee_name, employee_email, department_id || null, hire_date || null]);
    const [rows] = await pool.query('SELECT * FROM employees WHERE id_employees = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.update = async (req, res) => {
  const { employee_name, employee_email, department_id, hire_date } = req.body;
  try {
    const [result] = await pool.query('UPDATE employees SET employee_name = ?, employee_email = ?, department_id = ?, hire_date = ? WHERE id_employees = ?', [employee_name, employee_email, department_id || null, hire_date || null, req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Employee not found' });
    const [rows] = await pool.query('SELECT * FROM employees WHERE id_employees = ?', [req.params.id]);
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.remove = async (req, res) => {
  try {
    const [result] = await pool.query('DELETE FROM employees WHERE id_employees = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Employee not found' });
    res.json({ message: 'Employee deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};
