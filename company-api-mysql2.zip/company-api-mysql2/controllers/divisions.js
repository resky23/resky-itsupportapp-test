
const pool = require('../db');

exports.getAll = async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM division');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.getById = async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM division WHERE id_division = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Division not found' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.create = async (req, res) => {
  const { division_name } = req.body;
  if (!division_name) return res.status(400).json({ message: 'division_name is required' });
  try {
    const [result] = await pool.query('INSERT INTO division (division_name) VALUES (?)', [division_name]);
    const [rows] = await pool.query('SELECT * FROM division WHERE id_division = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.update = async (req, res) => {
  const { division_name } = req.body;
  try {
    const [result] = await pool.query('UPDATE division SET division_name = ? WHERE id_division = ?', [division_name, req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Division not found' });
    const [rows] = await pool.query('SELECT * FROM division WHERE id_division = ?', [req.params.id]);
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.remove = async (req, res) => {
  try {
    const [result] = await pool.query('DELETE FROM division WHERE id_division = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Division not found' });
    res.json({ message: 'Division deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};
