
const pool = require('../db');

exports.getAll = async (req, res) => {
  try {
    const sql = `
      SELECT d.id_department, d.department_name, d.id_division, dv.division_name
      FROM department d
      LEFT JOIN division dv ON d.id_division = dv.id_division
      ORDER BY d.id_department`;
    const [rows] = await pool.query(sql);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.getById = async (req, res) => {
  try {
    const sql = `
      SELECT d.id_department, d.department_name, d.id_division, dv.division_name
      FROM department d
      LEFT JOIN division dv ON d.id_division = dv.id_division
      WHERE d.id_department = ?`;
    const [rows] = await pool.query(sql, [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Department not found' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.create = async (req, res) => {
  const { department_name, id_division } = req.body;
  if (!department_name) return res.status(400).json({ message: 'department_name is required' });
  try {
    const [result] = await pool.query('INSERT INTO department (department_name, id_division) VALUES (?, ?)', [department_name, id_division || null]);
    const [rows] = await pool.query('SELECT * FROM department WHERE id_department = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.update = async (req, res) => {
  const { department_name, id_division } = req.body;
  try {
    const [result] = await pool.query('UPDATE department SET department_name = ?, id_division = ? WHERE id_department = ?', [department_name, id_division || null, req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Department not found' });
    const [rows] = await pool.query('SELECT * FROM department WHERE id_department = ?', [req.params.id]);
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};

exports.remove = async (req, res) => {
  try {
    const [result] = await pool.query('DELETE FROM department WHERE id_department = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Department not found' });
    res.json({ message: 'Department deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
};
