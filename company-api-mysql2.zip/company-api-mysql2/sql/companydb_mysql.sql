-- MySQL Database Script (3 tables: division, department, employees)
CREATE DATABASE IF NOT EXISTS companydb;
USE companydb;

-- Drop existing tables if exist (for reset purpose)
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS department;
DROP TABLE IF EXISTS division;

-- Table: division
CREATE TABLE division (
    id_division INT AUTO_INCREMENT PRIMARY KEY,
    division_name VARCHAR(100) NOT NULL
);

-- Table: department
CREATE TABLE department (
    id_department INT AUTO_INCREMENT PRIMARY KEY,
    id_division INT,
    department_name VARCHAR(100) NOT NULL,
    FOREIGN KEY (id_division) REFERENCES division(id_division)
);

-- Table: employees
CREATE TABLE employees (
    id_employees INT AUTO_INCREMENT PRIMARY KEY,
    employee_name VARCHAR(100) NOT NULL,
    employee_email VARCHAR(100) NOT NULL,
    department_id INT,
    hire_date DATE,
    FOREIGN KEY (department_id) REFERENCES department(id_department)
);

-- Insert sample data
INSERT INTO division (division_name) VALUES
('Corporate Services'),
('Operations'),
('Technology');

INSERT INTO department (id_division, department_name) VALUES
(1, 'Human Resources'),
(1, 'Finance'),
(2, 'Production'),
(3, 'IT Support'),
(3, 'Software Development');

INSERT INTO employees (employee_name, employee_email, department_id, hire_date) VALUES
('Budi Santoso', 'budi@company.com', 4, '2021-03-15'),
('Siti Aminah', 'siti@company.com', 1, '2020-07-10'),
('Andi Wijaya', 'andi@company.com', 5, '2022-11-01'),
('Rina Kurnia', 'rina@company.com', 2, '2023-01-05');
