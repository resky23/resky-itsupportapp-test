
# Company API (Node.js + Express + mysql2)

Project menyediakan REST API untuk **division**, **department**, dan **employees** sesuai soal ujian.

## Struktur
- `index.js` - entrypoint, middleware, route mounting
- `db.js` - koneksi pool mysql2
- `routes/` - route files untuk tiap resource
- `controllers/` - controller yang berisi query CRUD
- `sql/companydb_mysql.sql` - script SQL untuk membuat database & contoh data

## Cara pakai (local)
1. Pastikan MySQL berjalan dan import file SQL:  
   ```bash
   mysql -u root -p < sql/companydb_mysql.sql
   ```
2. Copy `.env.example` ke `.env` dan sesuaikan credential.
3. Install dependency:
   ```bash
   npm install
   ```
4. Jalankan server:
   ```bash
   npm start
   ```
5. API endpoints (base `http://localhost:3000/api`):
   - `GET /divisions`
   - `GET /divisions/:id`
   - `POST /divisions`
   - `PUT /divisions/:id`
   - `DELETE /divisions/:id`

   - `GET /departments` (supports join ke division)
   - `GET /departments/:id`
   - `POST /departments`
   - `PUT /departments/:id`
   - `DELETE /departments/:id`

   - `GET /employees` (supports join ke department + division)
   - `GET /employees/:id`
   - `POST /employees`
   - `PUT /employees/:id`
   - `DELETE /employees/:id`

## Catatan
- Semua input menggunakan prepared statements untuk mencegah SQL injection.
- Tanggal hire_date format `YYYY-MM-DD`.
