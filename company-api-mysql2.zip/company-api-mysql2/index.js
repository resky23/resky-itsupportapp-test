
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

const divisionRoutes = require('./routes/divisions');
const departmentRoutes = require('./routes/departments');
const employeeRoutes = require('./routes/employees');

app.use('/api/divisions', divisionRoutes);
app.use('/api/departments', departmentRoutes);
app.use('/api/employees', employeeRoutes);

app.get('/', (req, res) => res.send('Company API is running'));

app.listen(port, () => console.log(`Server running on http://localhost:${port}`));
